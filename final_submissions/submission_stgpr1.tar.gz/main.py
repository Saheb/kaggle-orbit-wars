"""Orbit Wars submission — player-count dispatcher.

2-player games  -> our trained Entity-Transformer neural policy (resolver).
4-player games  -> ajay (orbit_lite ProducerLite variant; same engine as
                   producer_v2 but WITHOUT the ETA-aware reinforcement-risk gate
                   — won the 4p FFA panel 39.1% vs producer_v2's 28.1%).

The player count is detected once per game from the distinct starting owners
and cached; it is re-detected whenever the step counter resets (new game in the
same process).
"""

import neural_agent as _neural
import ffa_agent as _ffa

# Per-process game state: cached player count + last seen step (to detect resets).
_STATE = {"n_players": None, "prev_step": -1}


def _count_players(obs) -> int:
    """Distinct owners (>=0) on the live board. 2 -> ours, >=3 -> ffa agent.

    `initial_planets` is all-neutral in the raw obs, so we count distinct owners
    in the live `planets` field — at step 0 each player owns their home planet,
    giving {0,1} for 2p and {0,1,2,3} for 4p.
    """
    if isinstance(obs, dict):
        planets = obs.get("planets") or []
        owners = [p[1] for p in planets]
    else:
        planets = getattr(obs, "planets", []) or []
        owners = [getattr(p, "owner", None) for p in planets]
    distinct = {int(o) for o in owners if o is not None and int(o) >= 0}
    n = len(distinct)
    return 4 if n >= 3 else 2


def _step_of(obs) -> int:
    if isinstance(obs, dict):
        return int(obs.get("step", 0))
    return int(getattr(obs, "step", 0))


def agent(obs, cfg=None):
    step_now = _step_of(obs)
    if _STATE["n_players"] is None or step_now <= _STATE["prev_step"]:
        _STATE["n_players"] = _count_players(obs)
    _STATE["prev_step"] = step_now

    if _STATE["n_players"] >= 4:
        return _ffa.agent(obs)
    return _neural.agent(obs, cfg)
